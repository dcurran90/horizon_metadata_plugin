# The name of the panel to be added to HORIZON_CONFIG. Required.
PANEL = 'volumes'

# The name of the dashboard the PANEL associated with. Required.
PANEL_DASHBOARD = 'project'

# Python panel class of the PANEL to be added.
ADD_PANEL = 'horizon_metadata_plugin.content.volumes.panel.Volumes'

