


from horizon_metadata_plugin.api.rest import swift_with_meta  # noqa
from horizon_metadata_plugin.api.rest import cinder_with_meta  # noqa
